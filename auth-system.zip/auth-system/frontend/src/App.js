import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import VerifyOTPPage from './pages/VerifyOTPPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import ResetPasswordPage from './pages/ResetPasswordPage';
import DashboardPage from './pages/DashboardPage';
import './styles/global.css';

// ─── Protected Route ───────────────────────────────────────────────────────────
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return <div className="page-loader"><div className="loader-ring" /></div>;
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

// ─── Public Route (redirect if logged in) ─────────────────────────────────────
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return <div className="page-loader"><div className="loader-ring" /></div>;
  return !isAuthenticated ? children : <Navigate to="/dashboard" replace />;
};

// ─── Theme Toggle ──────────────────────────────────────────────────────────────
const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark');
  
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  return (
    <div className="app" data-theme={theme}>
      {React.cloneElement(children, { theme, setTheme })}
    </div>
  );
};

function AppRoutes({ theme, setTheme }) {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<PublicRoute><LoginPage theme={theme} setTheme={setTheme} /></PublicRoute>} />
      <Route path="/register" element={<PublicRoute><RegisterPage theme={theme} setTheme={setTheme} /></PublicRoute>} />
      <Route path="/verify-email" element={<VerifyOTPPage theme={theme} setTheme={setTheme} />} />
      <Route path="/forgot-password" element={<PublicRoute><ForgotPasswordPage theme={theme} setTheme={setTheme} /></PublicRoute>} />
      <Route path="/reset-password" element={<PublicRoute><ResetPasswordPage theme={theme} setTheme={setTheme} /></PublicRoute>} />
      <Route path="/dashboard" element={<ProtectedRoute><DashboardPage theme={theme} setTheme={setTheme} /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <GoogleOAuthProvider clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID || ''}>
      <AuthProvider>
        <Router>
          <ThemeProvider>
            <AppRoutes />
          </ThemeProvider>
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: { background: '#1e1e3a', color: '#e2e8f0', border: '1px solid rgba(99,102,241,0.3)', borderRadius: '12px' },
              success: { iconTheme: { primary: '#10b981', secondary: '#1e1e3a' } },
              error: { iconTheme: { primary: '#ef4444', secondary: '#1e1e3a' } },
            }}
          />
        </Router>
      </AuthProvider>
    </GoogleOAuthProvider>
  );
}
