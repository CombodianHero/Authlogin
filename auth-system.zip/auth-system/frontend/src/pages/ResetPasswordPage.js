import React, { useState, useMemo } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../utils/api';

const EyeIcon = ({ open }) => open
  ? <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
  : <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>;

const passwordChecks = [
  { key: 'length', label: '8+ characters', test: v => v.length >= 8 },
  { key: 'upper', label: 'Uppercase', test: v => /[A-Z]/.test(v) },
  { key: 'lower', label: 'Lowercase', test: v => /[a-z]/.test(v) },
  { key: 'number', label: 'Number', test: v => /[0-9]/.test(v) },
  { key: 'special', label: 'Special char', test: v => /[!@#$%^&*(),.?":{}|<>]/.test(v) },
];

export default function ResetPasswordPage({ theme, setTheme }) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');

  const [form, setForm] = useState({ password: '', confirmPassword: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState({});

  const passChecks = useMemo(() =>
    passwordChecks.map(c => ({ ...c, met: c.test(form.password) })),
    [form.password]
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!form.password) errs.password = 'Password is required';
    else if (!passChecks.every(c => c.met)) errs.password = 'Password doesn\'t meet requirements';
    if (form.password !== form.confirmPassword) errs.confirmPassword = 'Passwords do not match';
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setLoading(true);
    try {
      await api.post('/auth/reset-password', { token, ...form });
      setSuccess(true);
      toast.success('Password reset successfully!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to reset password.');
    } finally {
      setLoading(false);
    }
  };

  if (!token) {
    return (
      <div className="auth-layout">
        <div className="auth-card" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 52, marginBottom: 16 }}>❌</div>
          <h2 style={{ color: 'var(--text-primary)', marginBottom: 8 }}>Invalid Link</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: 24 }}>This reset link is invalid or has expired.</p>
          <Link to="/forgot-password" className="btn btn-primary" style={{ display: 'inline-flex', width: 'auto', padding: '12px 28px' }}>Request New Link</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-layout">
      <button className="theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
        {theme === 'dark' ? '☀️' : '🌙'}
      </button>

      <div className="auth-card">
        <div className="auth-logo">
          <div className="logo-icon-wrapper">🔐</div>
          <span className="logo-text">AuthSystem</span>
        </div>

        {success ? (
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 52, marginBottom: 16 }}>✅</div>
            <h2 className="auth-title">Password updated!</h2>
            <p style={{ color: 'var(--text-secondary)', margin: '12px 0 24px' }}>
              Your password has been reset successfully. Sign in with your new password.
            </p>
            <button className="btn btn-primary" onClick={() => navigate('/login')}>
              Sign In Now
            </button>
          </div>
        ) : (
          <>
            <div className="auth-header">
              <h1 className="auth-title">Set new password</h1>
              <p className="auth-subtitle">Choose a strong password for your account</p>
            </div>

            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label className="form-label">New Password</label>
                <div className="input-wrapper">
                  <span className="input-icon">🔑</span>
                  <input
                    type={showPass ? 'text' : 'password'} name="password"
                    className={`form-input form-input-icon ${errors.password ? 'error' : ''}`}
                    placeholder="Create a strong password" value={form.password}
                    onChange={e => { setForm(p => ({...p, password: e.target.value})); setErrors(p => ({...p, password: ''})); }}
                    style={{ paddingRight: '44px' }} autoComplete="new-password"
                  />
                  <button type="button" className="password-toggle" onClick={() => setShowPass(!showPass)}>
                    <EyeIcon open={showPass} />
                  </button>
                </div>
                {errors.password && <p className="form-error">⚠ {errors.password}</p>}

                {form.password && (
                  <div className="password-strength" style={{ marginTop: 10 }}>
                    <div className="strength-checklist">
                      {passChecks.map(c => (
                        <div key={c.key} className={`strength-item ${c.met ? 'met' : ''}`}>
                          <span>{c.met ? '✓' : '○'}</span>{c.label}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Confirm Password</label>
                <div className="input-wrapper">
                  <span className="input-icon">🔒</span>
                  <input
                    type="password" name="confirmPassword"
                    className={`form-input form-input-icon ${errors.confirmPassword ? 'error' : ''}`}
                    placeholder="Repeat your password" value={form.confirmPassword}
                    onChange={e => { setForm(p => ({...p, confirmPassword: e.target.value})); setErrors(p => ({...p, confirmPassword: ''})); }}
                    autoComplete="new-password"
                  />
                </div>
                {errors.confirmPassword && <p className="form-error">⚠ {errors.confirmPassword}</p>}
              </div>

              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? <><div className="btn-spinner" /> Updating password...</> : 'Update Password'}
              </button>
            </form>

            <div className="auth-footer"><Link to="/login">← Back to sign in</Link></div>
          </>
        )}
      </div>
    </div>
  );
}
