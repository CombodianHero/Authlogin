import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../utils/api';

export default function ForgotPasswordPage({ theme, setTheme }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email) { setError('Email is required'); return; }
    if (!/\S+@\S+\.\S+/.test(email)) { setError('Enter a valid email'); return; }

    setLoading(true);
    setError('');
    try {
      await api.post('/auth/forgot-password', { email });
      setSent(true);
      toast.success('Password reset email sent!');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to send reset email.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-layout">
      <button className="theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
        {theme === 'dark' ? '☀️' : '🌙'}
      </button>

      <div className="auth-card" style={{ textAlign: 'center' }}>
        <div className="auth-logo" style={{ justifyContent: 'center' }}>
          <div className="logo-icon-wrapper">🔐</div>
          <span className="logo-text">AuthSystem</span>
        </div>

        {sent ? (
          <>
            <div style={{ fontSize: 52, marginBottom: 16 }}>📨</div>
            <div className="auth-header">
              <h1 className="auth-title">Check your email</h1>
              <p className="auth-subtitle">
                We've sent a password reset link to<br/>
                <strong style={{ color: 'var(--accent-primary)' }}>{email}</strong>
              </p>
            </div>
            <div className="alert alert-info">
              🔒 The link expires in 15 minutes. Check your spam folder if you don't see it.
            </div>
            <div className="auth-footer">
              <Link to="/login">← Back to sign in</Link>
            </div>
          </>
        ) : (
          <>
            <div style={{ fontSize: 52, marginBottom: 16 }}>🔑</div>
            <div className="auth-header">
              <h1 className="auth-title">Forgot password?</h1>
              <p className="auth-subtitle">No worries — we'll send you reset instructions</p>
            </div>

            {error && <div className="alert alert-error">{error}</div>}

            <form onSubmit={handleSubmit} noValidate style={{ textAlign: 'left' }}>
              <div className="form-group">
                <label className="form-label">Email Address</label>
                <div className="input-wrapper">
                  <span className="input-icon">✉️</span>
                  <input
                    type="email"
                    className={`form-input form-input-icon ${error ? 'error' : ''}`}
                    placeholder="you@example.com"
                    value={email}
                    onChange={e => { setEmail(e.target.value); setError(''); }}
                    autoComplete="email" autoFocus
                  />
                </div>
              </div>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? <><div className="btn-spinner" /> Sending link...</> : 'Send Reset Link'}
              </button>
            </form>

            <div className="auth-footer" style={{ marginTop: 20 }}>
              <Link to="/login">← Back to sign in</Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
