import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

const formatDate = (date) => {
  if (!date) return 'Never';
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
};

const getInitials = (name) => {
  return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'U';
};

export default function DashboardPage({ theme, setTheme }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [loggingOut, setLoggingOut] = useState(false);

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await logout();
      toast.success('Signed out successfully');
      navigate('/login');
    } catch {
      navigate('/login');
    }
  };

  if (!user) return null;

  return (
    <div className="dashboard-layout">
      <div className="dashboard-container">
        {/* Nav */}
        <div className="dashboard-nav">
          <div className="nav-logo">
            <div className="logo-icon-wrapper">🔐</div>
            <span className="logo-text">AuthSystem</span>
          </div>
          <div className="nav-actions">
            <button
              className="theme-toggle"
              style={{ position: 'static', width: 36, height: 36 }}
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            >
              {theme === 'dark' ? '☀️' : '🌙'}
            </button>
            <button
              className="btn btn-secondary btn-logout"
              onClick={handleLogout}
              disabled={loggingOut}
              style={{ width: 'auto', padding: '8px 18px', fontSize: 13 }}
            >
              {loggingOut ? '...' : '↪ Sign Out'}
            </button>
          </div>
        </div>

        {/* Welcome Banner */}
        <div className="dashboard-card" style={{
          background: 'linear-gradient(135deg, rgba(99,102,241,0.15) 0%, rgba(168,85,247,0.1) 100%)',
          borderColor: 'rgba(99,102,241,0.3)',
          marginBottom: 20,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 28 }}>👋</span>
            <div>
              <h2 style={{ fontSize: 20, fontWeight: 800, color: 'var(--text-primary)' }}>
                Welcome back, {user.fullName.split(' ')[0]}!
              </h2>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>
                Last login: {formatDate(user.lastLogin)}
              </p>
            </div>
          </div>
        </div>

        {/* Profile Card */}
        <div className="dashboard-card">
          <h3 className="section-title">👤 Profile</h3>
          <div className="profile-header">
            <div className="avatar-container">
              <div className="avatar">
                {user.profilePicture
                  ? <img src={user.profilePicture} alt={user.fullName} />
                  : getInitials(user.fullName)
                }
              </div>
              {user.isEmailVerified && (
                <div className="verified-badge" title="Verified">✓</div>
              )}
            </div>
            <div className="profile-info">
              <div className="name">{user.fullName}</div>
              <div className="username">@{user.username}</div>
              <div className="email">{user.email}</div>
              <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {user.isEmailVerified
                  ? <span className="badge badge-verified">✓ Verified</span>
                  : <span className="badge badge-unverified">⚠ Unverified</span>
                }
                {user.authProvider === 'google' && (
                  <span className="badge badge-google">🔍 Google Account</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="dashboard-card">
          <h3 className="section-title">📊 Account Overview</h3>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-icon">📅</div>
              <div className="stat-label">Member Since</div>
              <div className="stat-value">
                {new Date(user.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">🔐</div>
              <div className="stat-label">Auth Method</div>
              <div className="stat-value" style={{ textTransform: 'capitalize' }}>
                {user.authProvider === 'google' ? '🔍 Google' : '📧 Email'}
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">{user.isEmailVerified ? '✅' : '⚠️'}</div>
              <div className="stat-label">Email Status</div>
              <div className="stat-value" style={{ color: user.isEmailVerified ? 'var(--success)' : 'var(--warning)' }}>
                {user.isEmailVerified ? 'Verified' : 'Unverified'}
              </div>
            </div>
          </div>
        </div>

        {/* Account Details */}
        <div className="dashboard-card">
          <h3 className="section-title">⚙️ Account Details</h3>
          <div style={{ display: 'grid', gap: 12 }}>
            {[
              { label: 'Full Name', value: user.fullName, icon: '👤' },
              { label: 'Username', value: `@${user.username}`, icon: '🏷️' },
              { label: 'Email', value: user.email, icon: '✉️' },
              { label: 'Account Created', value: formatDate(user.createdAt), icon: '📅' },
              { label: 'Last Login', value: formatDate(user.lastLogin), icon: '🕐' },
            ].map(item => (
              <div key={item.label} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '12px 16px',
                background: 'var(--bg-input)',
                borderRadius: 10,
                border: '1px solid var(--border-color)',
              }}>
                <span style={{ fontSize: 16, minWidth: 20 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    {item.label}
                  </div>
                  <div style={{ fontSize: 14, color: 'var(--text-primary)', fontWeight: 500, marginTop: 1 }}>
                    {item.value}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security Section */}
        <div className="dashboard-card">
          <h3 className="section-title">🔒 Security</h3>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {user.authProvider === 'local' && (
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => navigate('/forgot-password')}
                style={{ width: 'auto' }}
              >
                🔑 Change Password
              </button>
            )}
            <button
              className="btn btn-secondary btn-sm"
              style={{ width: 'auto', color: 'var(--error)', borderColor: 'rgba(239,68,68,0.3)' }}
              onClick={handleLogout}
              disabled={loggingOut}
            >
              ↪ Sign Out
            </button>
          </div>
        </div>

        <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--text-muted)', padding: '12px 0 24px' }}>
          AuthSystem — Production-ready authentication 🔐
        </p>
      </div>
    </div>
  );
}
