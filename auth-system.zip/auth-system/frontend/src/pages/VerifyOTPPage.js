import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';

const OTP_LENGTH = 6;
const OTP_EXPIRE = 5 * 60; // 5 minutes in seconds

export default function VerifyOTPPage({ theme, setTheme }) {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { login } = useAuth();

  const email = state?.email || '';
  const [otp, setOtp] = useState(Array(OTP_LENGTH).fill(''));
  const [timer, setTimer] = useState(OTP_EXPIRE);
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [error, setError] = useState('');
  const inputs = useRef([]);

  // Redirect if no email
  useEffect(() => {
    if (!email) navigate('/register');
  }, [email, navigate]);

  // Countdown timer
  useEffect(() => {
    if (timer <= 0) return;
    const interval = setInterval(() => setTimer(t => t - 1), 1000);
    return () => clearInterval(interval);
  }, [timer]);

  const formatTime = (secs) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const handleInput = (index, value) => {
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    setError('');

    // Auto-focus next
    if (value && index < OTP_LENGTH - 1) inputs.current[index + 1]?.focus();

    // Auto-submit when all filled
    if (newOtp.every(d => d !== '') && value) {
      handleVerify(newOtp.join(''));
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputs.current[index - 1]?.focus();
    }
    if (e.key === 'ArrowLeft' && index > 0) inputs.current[index - 1]?.focus();
    if (e.key === 'ArrowRight' && index < OTP_LENGTH - 1) inputs.current[index + 1]?.focus();
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const text = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, OTP_LENGTH);
    if (!text) return;
    const newOtp = [...Array(OTP_LENGTH).fill('')];
    text.split('').forEach((d, i) => { newOtp[i] = d; });
    setOtp(newOtp);
    inputs.current[Math.min(text.length, OTP_LENGTH - 1)]?.focus();
    if (text.length === OTP_LENGTH) handleVerify(text);
  };

  const handleVerify = async (code) => {
    if (code.length < OTP_LENGTH) { setError('Please enter all 6 digits'); return; }
    if (timer <= 0) { setError('OTP has expired. Please request a new one.'); return; }

    setLoading(true);
    setError('');
    try {
      const { data } = await api.post('/auth/verify-otp', { email, otp: code });
      login(data.user, data.accessToken);
      toast.success('Email verified! Welcome aboard 🎉');
      navigate('/dashboard');
    } catch (err) {
      const msg = err.response?.data?.message || 'Verification failed.';
      setError(msg);
      setOtp(Array(OTP_LENGTH).fill(''));
      inputs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setResendLoading(true);
    setError('');
    try {
      await api.post('/auth/resend-otp', { email });
      setTimer(OTP_EXPIRE);
      setOtp(Array(OTP_LENGTH).fill(''));
      inputs.current[0]?.focus();
      toast.success('New verification code sent!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to resend OTP.');
    } finally {
      setResendLoading(false);
    }
  };

  return (
    <div className="auth-layout">
      <button className="theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
        {theme === 'dark' ? '☀️' : '🌙'}
      </button>

      <div className="auth-card" style={{ textAlign: 'center' }}>
        <div className="auth-logo" style={{ justifyContent: 'center' }}>
          <div className="logo-icon-wrapper">🔐</div>
          <span className="logo-text">AuthSystem</span>
        </div>

        <div style={{ fontSize: 52, marginBottom: 16 }}>📬</div>

        <div className="auth-header">
          <h1 className="auth-title">Check your inbox</h1>
          <p className="auth-subtitle">
            We sent a 6-digit code to<br />
            <strong style={{ color: 'var(--accent-primary)' }}>{email}</strong>
          </p>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        {/* OTP Inputs */}
        <div className="otp-container">
          {otp.map((digit, i) => (
            <input
              key={i}
              ref={el => inputs.current[i] = el}
              type="text" inputMode="numeric"
              className={`otp-input ${digit ? 'filled' : ''} ${error ? 'error' : ''}`}
              value={digit}
              onChange={e => handleInput(i, e.target.value)}
              onKeyDown={e => handleKeyDown(i, e)}
              onPaste={handlePaste}
              maxLength={1}
              disabled={loading}
              autoFocus={i === 0}
              aria-label={`OTP digit ${i + 1}`}
            />
          ))}
        </div>

        {/* Timer */}
        <div className={`timer-display ${timer <= 0 ? 'timer-expired' : ''}`}>
          {timer > 0 ? (
            <>⏱️ Code expires in <span className="timer-value">{formatTime(timer)}</span></>
          ) : (
            <span style={{ color: 'var(--error)' }}>⚠️ Code expired</span>
          )}
        </div>

        {/* Verify Button */}
        <button
          className="btn btn-primary"
          onClick={() => handleVerify(otp.join(''))}
          disabled={loading || otp.some(d => !d)}
          style={{ marginBottom: 12 }}
        >
          {loading ? <><div className="btn-spinner" /> Verifying...</> : 'Verify Email'}
        </button>

        {/* Resend */}
        <div style={{ marginTop: 8 }}>
          {timer > 0 ? (
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
              Didn't receive it? Check your spam folder.
            </p>
          ) : (
            <button
              className="btn btn-secondary"
              onClick={handleResend}
              disabled={resendLoading}
            >
              {resendLoading ? <><div className="btn-spinner" style={{ borderTopColor: 'var(--accent-primary)' }} /> Sending...</> : '🔄 Resend Code'}
            </button>
          )}
        </div>

        <div className="auth-footer" style={{ marginTop: 20 }}>
          <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Wrong email? </span>
          <a href="/register" style={{ fontSize: 13, color: 'var(--accent-primary)', fontWeight: 600 }}>Go back</a>
        </div>
      </div>
    </div>
  );
}
