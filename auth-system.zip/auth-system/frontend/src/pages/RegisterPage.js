import React, { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../utils/api';

const EyeIcon = ({ open }) => open
  ? <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
  : <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>;

const passwordChecks = [
  { key: 'length', label: '8+ characters', test: v => v.length >= 8 },
  { key: 'upper', label: 'Uppercase letter', test: v => /[A-Z]/.test(v) },
  { key: 'lower', label: 'Lowercase letter', test: v => /[a-z]/.test(v) },
  { key: 'number', label: 'Number', test: v => /[0-9]/.test(v) },
  { key: 'special', label: 'Special character', test: v => /[!@#$%^&*(),.?":{}|<>]/.test(v) },
];

const strengthConfig = [
  { label: 'Too weak', color: '#ef4444', width: '20%' },
  { label: 'Weak', color: '#f97316', width: '40%' },
  { label: 'Fair', color: '#f59e0b', width: '60%' },
  { label: 'Good', color: '#84cc16', width: '80%' },
  { label: 'Strong', color: '#10b981', width: '100%' },
];

export default function RegisterPage({ theme, setTheme }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '', username: '', email: '',
    password: '', confirmPassword: '', acceptTerms: false,
  });
  const [showPass, setShowPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const passChecks = useMemo(() =>
    passwordChecks.map(c => ({ ...c, met: c.test(form.password) })),
    [form.password]
  );

  const strengthScore = passChecks.filter(c => c.met).length;
  const strengthLevel = form.password ? Math.min(strengthScore - 1, 4) : -1;
  const strengthInfo = strengthLevel >= 0 ? strengthConfig[strengthLevel] : null;

  const validate = () => {
    const errs = {};
    if (!form.fullName.trim()) errs.fullName = 'Full name is required';
    else if (form.fullName.trim().length < 2) errs.fullName = 'Name must be at least 2 characters';

    if (!form.username.trim()) errs.username = 'Username is required';
    else if (form.username.length < 3) errs.username = 'Username must be at least 3 characters';
    else if (!/^[a-zA-Z0-9_]+$/.test(form.username)) errs.username = 'Letters, numbers, underscores only';

    if (!form.email) errs.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) errs.email = 'Enter a valid email';

    if (!form.password) errs.password = 'Password is required';
    else if (strengthScore < 5) errs.password = 'Password doesn\'t meet all requirements';

    if (!form.confirmPassword) errs.confirmPassword = 'Please confirm your password';
    else if (form.password !== form.confirmPassword) errs.confirmPassword = 'Passwords do not match';

    if (!form.acceptTerms) errs.acceptTerms = 'You must accept the Terms & Conditions';

    setErrors(errs);
    return !Object.keys(errs).length;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const { data } = await api.post('/auth/register', form);
      toast.success('Account created! Check your email for the verification code.');
      navigate('/verify-email', { state: { email: form.email } });
    } catch (err) {
      const resp = err.response?.data;
      if (resp?.errors) {
        const fieldErrors = {};
        resp.errors.forEach(e => { fieldErrors[e.field] = e.message; });
        setErrors(fieldErrors);
      } else if (resp?.field) {
        setErrors({ [resp.field]: resp.message });
      } else {
        toast.error(resp?.message || 'Registration failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-layout">
      <button className="theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
        {theme === 'dark' ? '☀️' : '🌙'}
      </button>

      <div className="auth-card" style={{ maxWidth: 500 }}>
        <div className="auth-logo">
          <div className="logo-icon-wrapper">🔐</div>
          <span className="logo-text">AuthSystem</span>
        </div>

        <div className="auth-header">
          <h1 className="auth-title">Create your account</h1>
          <p className="auth-subtitle">Join thousands of users — it's free forever</p>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          {/* Full Name */}
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <div className="input-wrapper">
              <span className="input-icon">👤</span>
              <input type="text" name="fullName"
                className={`form-input form-input-icon ${errors.fullName ? 'error' : ''}`}
                placeholder="John Doe" value={form.fullName} onChange={handleChange} autoComplete="name" />
            </div>
            {errors.fullName && <p className="form-error">⚠ {errors.fullName}</p>}
          </div>

          {/* Username */}
          <div className="form-group">
            <label className="form-label">Username</label>
            <div className="input-wrapper">
              <span className="input-icon">@</span>
              <input type="text" name="username"
                className={`form-input form-input-icon ${errors.username ? 'error' : ''}`}
                placeholder="johndoe123" value={form.username} onChange={handleChange}
                autoComplete="username" style={{ fontFamily: 'monospace' }} />
            </div>
            {errors.username && <p className="form-error">⚠ {errors.username}</p>}
          </div>

          {/* Email */}
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <div className="input-wrapper">
              <span className="input-icon">✉️</span>
              <input type="email" name="email"
                className={`form-input form-input-icon ${errors.email ? 'error' : ''}`}
                placeholder="you@example.com" value={form.email} onChange={handleChange} autoComplete="email" />
            </div>
            {errors.email && <p className="form-error">⚠ {errors.email}</p>}
          </div>

          {/* Password */}
          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="input-wrapper">
              <span className="input-icon">🔑</span>
              <input type={showPass ? 'text' : 'password'} name="password"
                className={`form-input form-input-icon ${errors.password ? 'error' : ''}`}
                placeholder="Create a strong password" value={form.password}
                onChange={handleChange} style={{ paddingRight: '44px' }} autoComplete="new-password" />
              <button type="button" className="password-toggle" onClick={() => setShowPass(!showPass)}>
                <EyeIcon open={showPass} />
              </button>
            </div>
            {errors.password && <p className="form-error">⚠ {errors.password}</p>}

            {/* Password Strength */}
            {form.password && (
              <div className="password-strength">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Password strength</span>
                  {strengthInfo && (
                    <span style={{ fontSize: '11px', fontWeight: 600, color: strengthInfo.color }}>
                      {strengthInfo.label}
                    </span>
                  )}
                </div>
                <div className="strength-bar">
                  <div className="strength-fill"
                    style={{ width: strengthInfo?.width || '0%', background: strengthInfo?.color || 'transparent' }} />
                </div>
                <div className="strength-checklist">
                  {passChecks.map(c => (
                    <div key={c.key} className={`strength-item ${c.met ? 'met' : ''}`}>
                      <span className="check-icon">{c.met ? '✓' : '○'}</span>
                      {c.label}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <div className="form-group">
            <label className="form-label">Confirm Password</label>
            <div className="input-wrapper">
              <span className="input-icon">🔒</span>
              <input type={showConfirmPass ? 'text' : 'password'} name="confirmPassword"
                className={`form-input form-input-icon ${errors.confirmPassword ? 'error' : form.confirmPassword && form.password === form.confirmPassword ? 'success' : ''}`}
                placeholder="Repeat your password" value={form.confirmPassword}
                onChange={handleChange} style={{ paddingRight: '44px' }} autoComplete="new-password" />
              <button type="button" className="password-toggle" onClick={() => setShowConfirmPass(!showConfirmPass)}>
                <EyeIcon open={showConfirmPass} />
              </button>
            </div>
            {errors.confirmPassword && <p className="form-error">⚠ {errors.confirmPassword}</p>}
          </div>

          {/* Terms */}
          <div className="form-group">
            <label className="checkbox-group">
              <input type="checkbox" name="acceptTerms" checked={form.acceptTerms} onChange={handleChange} />
              <div className="checkbox-custom"><span className="checkbox-check">✓</span></div>
              <span className="checkbox-label">
                I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
              </span>
            </label>
            {errors.acceptTerms && <p className="form-error" style={{ marginTop: '6px' }}>⚠ {errors.acceptTerms}</p>}
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? <><div className="btn-spinner" /> Creating account...</> : 'Create Account'}
          </button>
        </form>

        <div className="auth-footer">
          Already have an account? <Link to="/login">Sign in</Link>
        </div>
      </div>
    </div>
  );
}
