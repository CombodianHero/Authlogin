# 🔐 AuthSystem — Production-Ready Authentication

A complete, modern full-stack authentication system built with React, Node.js, MongoDB, and JWT.

---

## ✨ Features

| Feature | Status |
|---|---|
| Email + Password Login | ✅ |
| Registration with Validation | ✅ |
| Email OTP Verification | ✅ |
| Google OAuth 2.0 | ✅ |
| Forgot / Reset Password | ✅ |
| JWT (Access + Refresh Tokens) | ✅ |
| HTTP-Only Cookies | ✅ |
| bcrypt Password Hashing | ✅ |
| Rate Limiting | ✅ |
| NoSQL Injection Prevention | ✅ |
| Account Lockout | ✅ |
| Dark / Light Mode | ✅ |
| Fully Responsive | ✅ |
| Professional Email Templates | ✅ |
| User Dashboard | ✅ |

---

## 📁 Folder Structure

```
auth-system/
├── backend/
│   ├── config/
│   │   └── database.js          # MongoDB connection
│   ├── controllers/
│   │   └── authController.js    # All auth logic
│   ├── middleware/
│   │   ├── auth.js              # JWT protect middleware
│   │   └── validate.js          # Input validators
│   ├── models/
│   │   └── User.js              # Mongoose schema
│   ├── routes/
│   │   └── auth.js              # Express routes
│   ├── utils/
│   │   ├── emailService.js      # Nodemailer + HTML templates
│   │   └── jwtUtils.js          # Token helpers
│   ├── server.js                # Express app entry
│   ├── .env.example
│   └── package.json
│
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── context/
│   │   │   └── AuthContext.js   # Global auth state
│   │   ├── pages/
│   │   │   ├── LoginPage.js
│   │   │   ├── RegisterPage.js
│   │   │   ├── VerifyOTPPage.js
│   │   │   ├── ForgotPasswordPage.js
│   │   │   ├── ResetPasswordPage.js
│   │   │   └── DashboardPage.js
│   │   ├── styles/
│   │   │   └── global.css       # Full theme system
│   │   ├── utils/
│   │   │   └── api.js           # Axios + interceptors
│   │   ├── App.js
│   │   └── index.js
│   ├── .env.example
│   └── package.json
│
├── package.json                 # Root scripts
└── README.md
```

---

## 🚀 Local Setup

### Prerequisites
- Node.js 18+
- MongoDB Atlas account (free tier works)
- Gmail account with App Password
- Google Cloud Console project

---

### 1. Clone and Install

```bash
git clone <your-repo-url>
cd auth-system
npm install
npm run install:all
```

---

### 2. Configure Backend

```bash
cd backend
cp .env.example .env
```

Edit `.env`:

```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb+srv://...
JWT_SECRET=your-32-char-secret
JWT_EXPIRE=7d
JWT_REFRESH_SECRET=your-refresh-secret
JWT_REFRESH_EXPIRE=30d
COOKIE_SECRET=your-cookie-secret
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your-gmail-app-password
EMAIL_FROM=AuthSystem <your@gmail.com>
GOOGLE_CLIENT_ID=xxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-google-secret
CLIENT_URL=http://localhost:3000
OTP_EXPIRE_MINUTES=5
RESET_TOKEN_EXPIRE_MINUTES=15
```

---

### 3. Configure Frontend

```bash
cd frontend
cp .env.example .env
```

Edit `.env`:

```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_GOOGLE_CLIENT_ID=xxx.apps.googleusercontent.com
```

---

### 4. Run Development

```bash
# From root directory — starts both frontend and backend
npm run dev
```

- **Frontend:** http://localhost:3000
- **Backend:** http://localhost:5000
- **API Health:** http://localhost:5000/api/health

---

## 📧 Gmail SMTP Setup

1. Go to [Google Account](https://myaccount.google.com)
2. Enable **2-Factor Authentication**
3. Search for **"App Passwords"**
4. Generate a password for "Mail" / "Other"
5. Use that 16-character password as `SMTP_PASS`

---

## 🔑 Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project
3. Enable **Google+ API** or **Google Identity**
4. Go to **Credentials → OAuth 2.0 Client IDs**
5. Set Authorized JavaScript origins: `http://localhost:3000`
6. Set Authorized redirect URIs: `http://localhost:3000`
7. Copy **Client ID** and **Client Secret**

---

## 🛡️ Security Architecture

| Layer | Implementation |
|---|---|
| Passwords | bcrypt (12 rounds) |
| Tokens | JWT (Access 7d + Refresh 30d) |
| Cookies | HTTP-only, Secure, SameSite |
| Rate Limiting | 10 req/15min on auth routes |
| Input Sanitization | express-mongo-sanitize |
| Headers | helmet.js |
| Account Lockout | 5 failed attempts → 30min lock |
| OTP | 6-digit, 5min expiry, max 5 attempts |
| Reset Token | SHA-256 hashed, 15min expiry |

---

## ☁️ Deployment

### Backend → Render.com

1. Push code to GitHub
2. Create new **Web Service** on Render
3. Set **Root Directory** to `backend`
4. Build command: `npm install`
5. Start command: `node server.js`
6. Add all environment variables from `.env`
7. Set `NODE_ENV=production`

### Frontend → Vercel

1. Push code to GitHub
2. Import project in Vercel
3. Set **Root Directory** to `frontend`
4. Add environment variables:
   - `REACT_APP_API_URL=https://your-render-backend.onrender.com/api`
   - `REACT_APP_GOOGLE_CLIENT_ID=xxx`
5. Deploy!

### After Deployment

- Update `CLIENT_URL` in backend `.env` to your Vercel URL
- Update Google OAuth **Authorized Origins** with your Vercel URL
- Update Google OAuth **Redirect URIs** with your Vercel URL

---

## 🔌 API Reference

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| POST | `/api/auth/register` | Register new user | No |
| POST | `/api/auth/login` | Login with email/password | No |
| POST | `/api/auth/verify-otp` | Verify email OTP | No |
| POST | `/api/auth/resend-otp` | Resend OTP | No |
| POST | `/api/auth/google` | Google OAuth sign-in | No |
| POST | `/api/auth/forgot-password` | Send reset link | No |
| POST | `/api/auth/reset-password` | Reset with token | No |
| POST | `/api/auth/refresh` | Refresh access token | Cookie |
| GET | `/api/auth/me` | Get current user | JWT |
| POST | `/api/auth/logout` | Logout | JWT |
| GET | `/api/health` | Server health check | No |

---

## 🤝 Contributing

Pull requests are welcome. For major changes, please open an issue first.

## 📄 License

MIT
