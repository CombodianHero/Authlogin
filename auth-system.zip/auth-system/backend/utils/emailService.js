const nodemailer = require('nodemailer');

// ─── Transporter ──────────────────────────────────────────────────────────────
const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
    tls: {
      rejectUnauthorized: false,
    },
  });
};

// ─── Base Email Template ───────────────────────────────────────────────────────
const baseTemplate = (content, previewText = '') => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="x-apple-disable-message-reformatting"/>
  <title>AuthSystem</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #0f0f1a; color: #e2e8f0; }
    .wrapper { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
    .card { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); border-radius: 20px; overflow: hidden; border: 1px solid rgba(99,102,241,0.3); box-shadow: 0 25px 50px rgba(0,0,0,0.5); }
    .header { background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a855f7 100%); padding: 40px 30px; text-align: center; }
    .logo { display: inline-flex; align-items: center; gap: 10px; }
    .logo-icon { width: 44px; height: 44px; background: rgba(255,255,255,0.2); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; font-size: 22px; }
    .logo-text { font-size: 24px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px; }
    .body { padding: 40px 30px; }
    .greeting { font-size: 22px; font-weight: 700; color: #f1f5f9; margin-bottom: 12px; }
    .message { font-size: 15px; color: #94a3b8; line-height: 1.7; margin-bottom: 30px; }
    .otp-container { background: rgba(99,102,241,0.1); border: 1px solid rgba(99,102,241,0.3); border-radius: 16px; padding: 30px; text-align: center; margin: 30px 0; }
    .otp-label { font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: #6366f1; font-weight: 600; margin-bottom: 16px; }
    .otp-code { font-size: 48px; font-weight: 800; letter-spacing: 12px; color: #ffffff; font-family: 'Courier New', monospace; text-shadow: 0 0 30px rgba(99,102,241,0.8); }
    .otp-expires { font-size: 13px; color: #64748b; margin-top: 12px; }
    .btn { display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #ffffff !important; text-decoration: none; border-radius: 12px; font-weight: 600; font-size: 15px; margin: 20px 0; }
    .divider { height: 1px; background: rgba(99,102,241,0.2); margin: 25px 0; }
    .warning-box { background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); border-radius: 12px; padding: 16px 20px; margin: 24px 0; }
    .warning-icon { font-size: 16px; margin-right: 8px; }
    .warning-text { font-size: 13px; color: #fbbf24; line-height: 1.6; }
    .footer { background: rgba(0,0,0,0.3); padding: 24px 30px; text-align: center; }
    .footer-text { font-size: 12px; color: #475569; line-height: 1.8; }
    .footer-links { margin-top: 12px; }
    .footer-links a { color: #6366f1; text-decoration: none; font-size: 12px; margin: 0 8px; }
    @media (max-width: 600px) { .otp-code { font-size: 36px; letter-spacing: 8px; } .body { padding: 24px 20px; } }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="header">
        <div class="logo">
          <div class="logo-icon">🔐</div>
          <span class="logo-text">AuthSystem</span>
        </div>
      </div>
      <div class="body">
        ${content}
      </div>
      <div class="footer">
        <p class="footer-text">
          © ${new Date().getFullYear()} AuthSystem. All rights reserved.<br/>
          This is an automated email, please do not reply directly.<br/>
          If you did not request this, please ignore this email.
        </p>
        <div class="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
          <a href="#">Support</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
`;

// ─── OTP Verification Email ────────────────────────────────────────────────────
const sendOTPEmail = async ({ to, name, otp, expiryMinutes = 5 }) => {
  const transporter = createTransporter();

  const content = `
    <p class="greeting">Verify your email address 👋</p>
    <p class="message">
      Hi ${name},<br/><br/>
      Welcome to AuthSystem! To complete your registration and secure your account, 
      please verify your email address using the OTP below.
    </p>
    <div class="otp-container">
      <p class="otp-label">Your Verification Code</p>
      <p class="otp-code">${otp}</p>
      <p class="otp-expires">⏱️ Expires in ${expiryMinutes} minutes</p>
    </div>
    <p class="message">
      Enter this code on the verification page to activate your account.
      This code is single-use and will expire after ${expiryMinutes} minutes.
    </p>
    <div class="divider"></div>
    <div class="warning-box">
      <p class="warning-text">
        <span class="warning-icon">⚠️</span>
        <strong>Security Notice:</strong> AuthSystem will never ask you for this code via phone or email. 
        Do not share this code with anyone. If you didn't create an account, you can safely ignore this email.
      </p>
    </div>
  `;

  const mailOptions = {
    from: process.env.EMAIL_FROM,
    to,
    subject: `${otp} is your AuthSystem verification code`,
    html: baseTemplate(content),
    text: `Your AuthSystem verification code is: ${otp}. It expires in ${expiryMinutes} minutes.`,
  };

  return transporter.sendMail(mailOptions);
};

// ─── Password Reset Email ──────────────────────────────────────────────────────
const sendPasswordResetEmail = async ({ to, name, resetUrl, expiryMinutes = 15 }) => {
  const transporter = createTransporter();

  const content = `
    <p class="greeting">Reset your password 🔑</p>
    <p class="message">
      Hi ${name},<br/><br/>
      We received a request to reset the password for your AuthSystem account. 
      Click the button below to create a new password.
    </p>
    <div style="text-align: center; margin: 30px 0;">
      <a href="${resetUrl}" class="btn">Reset Password</a>
    </div>
    <p class="message" style="font-size: 13px; color: #64748b;">
      Or copy and paste this link in your browser:<br/>
      <span style="color: #6366f1; word-break: break-all;">${resetUrl}</span>
    </p>
    <div class="divider"></div>
    <p class="message" style="font-size: 13px;">
      ⏱️ This link will expire in <strong>${expiryMinutes} minutes</strong>.
    </p>
    <div class="warning-box">
      <p class="warning-text">
        <span class="warning-icon">⚠️</span>
        <strong>Security Notice:</strong> If you did not request a password reset, 
        please ignore this email. Your password will remain unchanged. 
        Consider securing your account if you believe someone else is attempting to access it.
      </p>
    </div>
  `;

  const mailOptions = {
    from: process.env.EMAIL_FROM,
    to,
    subject: 'Reset your AuthSystem password',
    html: baseTemplate(content),
    text: `Reset your password: ${resetUrl} (expires in ${expiryMinutes} minutes)`,
  };

  return transporter.sendMail(mailOptions);
};

// ─── Welcome Email ─────────────────────────────────────────────────────────────
const sendWelcomeEmail = async ({ to, name }) => {
  const transporter = createTransporter();

  const content = `
    <p class="greeting">Welcome to AuthSystem! 🎉</p>
    <p class="message">
      Hi ${name},<br/><br/>
      Your account has been successfully verified and is now fully active. 
      You're all set to explore everything AuthSystem has to offer.
    </p>
    <div style="background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.3); border-radius: 16px; padding: 24px; margin: 24px 0; text-align: center;">
      <div style="font-size: 48px; margin-bottom: 8px;">✅</div>
      <p style="color: #10b981; font-weight: 600; font-size: 16px;">Account Verified Successfully</p>
    </div>
    <p class="message">
      Your account is secured with industry-standard encryption and security practices. 
      Here are some tips to keep your account safe:
    </p>
    <ul style="color: #94a3b8; font-size: 14px; line-height: 2; padding-left: 20px; margin-bottom: 20px;">
      <li>Use a strong, unique password</li>
      <li>Never share your login credentials</li>
      <li>Log out from shared devices</li>
      <li>Contact support if you notice suspicious activity</li>
    </ul>
    <div class="divider"></div>
    <p class="message" style="font-size: 13px; color: #64748b;">
      Need help? Contact our support team anytime.
    </p>
  `;

  const mailOptions = {
    from: process.env.EMAIL_FROM,
    to,
    subject: 'Welcome to AuthSystem — Account Verified!',
    html: baseTemplate(content),
    text: `Welcome to AuthSystem, ${name}! Your account is now verified.`,
  };

  return transporter.sendMail(mailOptions);
};

module.exports = { sendOTPEmail, sendPasswordResetEmail, sendWelcomeEmail };
