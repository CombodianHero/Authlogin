const crypto = require('crypto');
const { OAuth2Client } = require('google-auth-library');
const User = require('../models/User');
const { sendOTPEmail, sendPasswordResetEmail, sendWelcomeEmail } = require('../utils/emailService');
const {
  generateAccessToken,
  generateRefreshToken,
  verifyToken,
  setTokenCookies,
  clearTokenCookies,
} = require('../utils/jwtUtils');

const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// ─── Helper: Send token response ───────────────────────────────────────────────
const sendTokenResponse = (user, statusCode, res, message = 'Success') => {
  const accessToken = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken(user._id);
  setTokenCookies(res, accessToken, refreshToken);

  const userResponse = {
    _id: user._id,
    fullName: user.fullName,
    username: user.username,
    email: user.email,
    profilePicture: user.profilePicture,
    isEmailVerified: user.isEmailVerified,
    authProvider: user.authProvider,
    lastLogin: user.lastLogin,
    createdAt: user.createdAt,
  };

  res.status(statusCode).json({
    success: true,
    message,
    accessToken,
    user: userResponse,
  });
};

// ─── @POST /api/auth/register ──────────────────────────────────────────────────
exports.register = async (req, res) => {
  try {
    const { fullName, username, email, password } = req.body;

    // Check if email or username already exists
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      const field = existingUser.email === email ? 'email' : 'username';
      return res.status(409).json({
        success: false,
        message: `An account with this ${field} already exists.`,
        field,
      });
    }

    // Create user
    const user = await User.create({
      fullName,
      username,
      email,
      passwordHash: password,
      authProvider: 'local',
    });

    // Generate and save OTP
    const otp = user.generateOTP();
    await user.save();

    // Send verification email
    await sendOTPEmail({
      to: email,
      name: fullName,
      otp,
      expiryMinutes: parseInt(process.env.OTP_EXPIRE_MINUTES) || 5,
    });

    res.status(201).json({
      success: true,
      message: 'Account created! Please check your email for a verification code.',
      email,
    });
  } catch (error) {
    console.error('Register error:', error);
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      return res.status(409).json({
        success: false,
        message: `An account with this ${field} already exists.`,
      });
    }
    res.status(500).json({ success: false, message: 'Server error during registration.' });
  }
};

// ─── @POST /api/auth/verify-otp ───────────────────────────────────────────────
exports.verifyOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;

    const user = await User.findOne({ email }).select('+otpCode +otpExpiry +otpAttempts');
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    if (user.isEmailVerified) {
      return res.status(400).json({ success: false, message: 'Email is already verified.' });
    }

    const result = user.verifyOTP(otp);
    if (!result.valid) {
      await user.save();
      return res.status(400).json({ success: false, message: result.reason });
    }

    // Mark as verified and clear OTP
    user.isEmailVerified = true;
    user.otpCode = undefined;
    user.otpExpiry = undefined;
    user.otpAttempts = 0;
    user.lastLogin = new Date();
    await user.save();

    // Send welcome email (non-blocking)
    sendWelcomeEmail({ to: user.email, name: user.fullName }).catch(console.error);

    sendTokenResponse(user, 200, res, 'Email verified successfully! Welcome aboard.');
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ success: false, message: 'Server error during OTP verification.' });
  }
};

// ─── @POST /api/auth/resend-otp ───────────────────────────────────────────────
exports.resendOTP = async (req, res) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ email }).select('+otpCode +otpExpiry');
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    if (user.isEmailVerified) {
      return res.status(400).json({ success: false, message: 'Email is already verified.' });
    }

    // Check cooldown (prevent spam)
    if (user.otpExpiry && user.otpExpiry > new Date(Date.now() + 4 * 60 * 1000)) {
      return res.status(429).json({
        success: false,
        message: 'Please wait before requesting a new OTP.',
      });
    }

    const otp = user.generateOTP();
    await user.save();

    await sendOTPEmail({
      to: user.email,
      name: user.fullName,
      otp,
      expiryMinutes: parseInt(process.env.OTP_EXPIRE_MINUTES) || 5,
    });

    res.json({
      success: true,
      message: 'A new verification code has been sent to your email.',
    });
  } catch (error) {
    console.error('Resend OTP error:', error);
    res.status(500).json({ success: false, message: 'Failed to resend OTP.' });
  }
};

// ─── @POST /api/auth/login ─────────────────────────────────────────────────────
exports.login = async (req, res) => {
  try {
    const { email, password, rememberMe } = req.body;

    const user = await User.findOne({ email }).select('+passwordHash +loginAttempts +lockUntil');
    
    if (!user || user.authProvider !== 'local') {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    // Check if account is locked
    if (user.isLocked) {
      return res.status(423).json({
        success: false,
        message: 'Account temporarily locked due to too many failed attempts. Try again in 30 minutes.',
      });
    }

    // Verify password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      await user.incrementLoginAttempts();
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    // Check email verification
    if (!user.isEmailVerified) {
      // Resend OTP automatically
      const otp = user.generateOTP();
      await user.save();
      sendOTPEmail({ to: user.email, name: user.fullName, otp }).catch(console.error);

      return res.status(403).json({
        success: false,
        message: 'Please verify your email. A new code has been sent.',
        code: 'EMAIL_NOT_VERIFIED',
        email: user.email,
      });
    }

    // Reset login attempts on success
    user.loginAttempts = 0;
    user.lockUntil = undefined;
    user.lastLogin = new Date();
    await user.save();

    sendTokenResponse(user, 200, res, 'Login successful!');
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error during login.' });
  }
};

// ─── @POST /api/auth/google ────────────────────────────────────────────────────
exports.googleAuth = async (req, res) => {
  try {
    const { idToken } = req.body;

    if (!idToken) {
      return res.status(400).json({ success: false, message: 'Google token is required.' });
    }

    // Verify Google token
    const ticket = await googleClient.verifyIdToken({
      idToken,
      audience: process.env.GOOGLE_CLIENT_ID,
    });

    const { sub: googleId, name, email, picture } = ticket.getPayload();

    // Check if user exists with this Google ID
    let user = await User.findOne({ $or: [{ googleId }, { email }] });

    if (user) {
      // Update Google info if needed
      if (!user.googleId) {
        user.googleId = googleId;
        user.authProvider = 'google';
      }
      if (picture && !user.profilePicture) {
        user.profilePicture = picture;
      }
      user.isEmailVerified = true;
      user.lastLogin = new Date();
      await user.save();
    } else {
      // Create new user from Google
      const username = email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '') + '_' + Math.floor(Math.random() * 1000);
      user = await User.create({
        fullName: name,
        username,
        email,
        googleId,
        profilePicture: picture,
        isEmailVerified: true,
        authProvider: 'google',
        lastLogin: new Date(),
      });
    }

    sendTokenResponse(user, 200, res, 'Google sign-in successful!');
  } catch (error) {
    console.error('Google auth error:', error);
    res.status(401).json({ success: false, message: 'Google authentication failed.' });
  }
};

// ─── @POST /api/auth/forgot-password ──────────────────────────────────────────
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ email });

    // Always respond positively to prevent email enumeration
    if (!user) {
      return res.json({
        success: true,
        message: 'If an account with this email exists, a reset link has been sent.',
      });
    }

    if (user.authProvider === 'google') {
      return res.status(400).json({
        success: false,
        message: 'This account uses Google sign-in. Please sign in with Google.',
      });
    }

    const rawToken = user.generateResetToken();
    await user.save();

    const resetUrl = `${process.env.CLIENT_URL}/reset-password?token=${rawToken}`;

    await sendPasswordResetEmail({
      to: user.email,
      name: user.fullName,
      resetUrl,
      expiryMinutes: parseInt(process.env.RESET_TOKEN_EXPIRE_MINUTES) || 15,
    });

    res.json({
      success: true,
      message: 'If an account with this email exists, a reset link has been sent.',
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ success: false, message: 'Failed to send reset email.' });
  }
};

// ─── @POST /api/auth/reset-password ───────────────────────────────────────────
exports.resetPassword = async (req, res) => {
  try {
    const { token, password } = req.body;

    // Hash the token to compare with stored hashed token
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpiry: { $gt: Date.now() },
    }).select('+resetPasswordToken +resetPasswordExpiry');

    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired reset link. Please request a new one.',
      });
    }

    user.passwordHash = password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpiry = undefined;
    user.loginAttempts = 0;
    user.lockUntil = undefined;
    await user.save();

    clearTokenCookies(res);

    res.json({
      success: true,
      message: 'Password reset successfully. Please log in with your new password.',
    });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ success: false, message: 'Failed to reset password.' });
  }
};

// ─── @GET /api/auth/me ─────────────────────────────────────────────────────────
exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ─── @POST /api/auth/logout ────────────────────────────────────────────────────
exports.logout = (req, res) => {
  clearTokenCookies(res);
  res.json({ success: true, message: 'Logged out successfully.' });
};

// ─── @POST /api/auth/refresh ───────────────────────────────────────────────────
exports.refreshToken = async (req, res) => {
  try {
    const refreshToken = req.cookies?.refreshToken;
    if (!refreshToken) {
      return res.status(401).json({ success: false, message: 'No refresh token.' });
    }

    const decoded = verifyToken(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user = await User.findById(decoded.id);

    if (!user || !user.isActive) {
      return res.status(401).json({ success: false, message: 'Invalid refresh token.' });
    }

    const newAccessToken = generateAccessToken(user._id);
    const newRefreshToken = generateRefreshToken(user._id);
    setTokenCookies(res, newAccessToken, newRefreshToken);

    res.json({ success: true, accessToken: newAccessToken });
  } catch (error) {
    clearTokenCookies(res);
    res.status(401).json({ success: false, message: 'Session expired. Please log in again.' });
  }
};
